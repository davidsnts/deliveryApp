import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

let dbInstance: Database.Database | null = null;

const DEFAULT_CATEGORIES = [
  { id: "pratos", name: "Pratos", icon: "🍲" },
  { id: "bebidas", name: "Bebidas", icon: "🥤" },
];

export function getDb(): Database.Database {
  if (dbInstance) {
    return dbInstance;
  }

  // Ensure data directory exists
  const dataDir = path.join(process.cwd(), "data");
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  const dbPath = path.join(dataDir, "delivery.db");
  const db = new Database(dbPath);

  // Enable WAL mode for high performance
  db.pragma("journal_mode = WAL");

  // Create Tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      icon TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      price REAL NOT NULL,
      original_price REAL,
      image TEXT NOT NULL,
      category_id TEXT NOT NULL,
      restaurant_id TEXT NOT NULL DEFAULT 'rest-1',
      restaurant_name TEXT NOT NULL DEFAULT 'Manga Com Pimenta',
      rating REAL DEFAULT 5.0,
      reviews_count INTEGER DEFAULT 0,
      delivery_time TEXT DEFAULT '30-40 min',
      is_popular INTEGER DEFAULT 0,
      is_offer INTEGER DEFAULT 0,
      free_delivery INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      created_at TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      delivery_address_json TEXT NOT NULL,
      items_json TEXT NOT NULL,
      subtotal REAL NOT NULL,
      delivery_fee REAL NOT NULL,
      discount REAL NOT NULL,
      total REAL NOT NULL,
      payment_method TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pendente',
      device_id TEXT,
      notes TEXT
    );
  `);
  // Migrate existing databases: add notes column if it doesn't exist yet
  try {
    db.exec("ALTER TABLE orders ADD COLUMN notes TEXT;");
  } catch {
    // Column already exists — safe to ignore
  }

  // Initialize basic categories if table is empty
  const categoryCount = (db.prepare("SELECT COUNT(*) as count FROM categories").get() as { count: number }).count;
  if (categoryCount === 0) {
    const insertCat = db.prepare("INSERT INTO categories (id, name, icon) VALUES (?, ?, ?)");
    const insertCatTx = db.transaction(() => {
      for (const cat of DEFAULT_CATEGORIES) {
        insertCat.run(cat.id, cat.name, cat.icon);
      }
    });
    insertCatTx();
  }

  dbInstance = db;
  return db;
}

export function resetDatabase(): void {
  const db = getDb();
  db.exec(`
    DELETE FROM products;
    DELETE FROM orders;
    DELETE FROM categories;
  `);

  const insertCat = db.prepare("INSERT INTO categories (id, name, icon) VALUES (?, ?, ?)");
  const insertCatTx = db.transaction(() => {
    for (const cat of DEFAULT_CATEGORIES) {
      insertCat.run(cat.id, cat.name, cat.icon);
    }
  });
  insertCatTx();
}

import { NextResponse } from "next/server";
import { getDb } from "@/app/lib/db";
import { OrderStatus } from "@/app/types";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { status }: { status: OrderStatus } = await request.json();

    if (!status) {
      return NextResponse.json({ error: "Status não informado" }, { status: 400 });
    }

    const db = getDb();
    const result = db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, id);

    if (result.changes === 0) {
      return NextResponse.json({ error: "Pedido não encontrado" }, { status: 404 });
    }

    return NextResponse.json({ success: true, id, status });
  } catch (error) {
    console.error("Erro ao atualizar status do pedido:", error);
    return NextResponse.json({ error: "Erro ao atualizar status do pedido" }, { status: 500 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const db = getDb();

    const result = db.prepare("DELETE FROM orders WHERE id = ?").run(id);

    if (result.changes === 0) {
      return NextResponse.json({ error: "Pedido não encontrado" }, { status: 404 });
    }

    return NextResponse.json({ success: true, deletedId: id });
  } catch (error) {
    console.error("Erro ao excluir pedido:", error);
    return NextResponse.json({ error: "Erro ao excluir pedido" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { getDb } from "@/app/lib/db";
import { Order } from "@/app/types";

function rowToOrder(row: any): Order {
  return {
    id: row.id,
    createdAt: row.created_at,
    customer: {
      name: row.customer_name,
      phone: row.customer_phone,
    },
    deliveryAddress: JSON.parse(row.delivery_address_json),
    items: JSON.parse(row.items_json),
    subtotal: Number(row.subtotal),
    deliveryFee: Number(row.delivery_fee),
    discount: Number(row.discount),
    total: Number(row.total),
    paymentMethod: row.payment_method,
    status: row.status,
    deviceId: row.device_id || undefined,
    notes: row.notes || undefined,
  };
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const deviceId = searchParams.get("deviceId");
    const db = getDb();

    let rows: any[] = [];
    if (deviceId) {
      rows = db
        .prepare("SELECT * FROM orders WHERE device_id = ? ORDER BY rowid DESC")
        .all(deviceId);
    } else {
      rows = db.prepare("SELECT * FROM orders ORDER BY rowid DESC").all();
    }

    const orders: Order[] = rows.map(rowToOrder);
    return NextResponse.json(orders);
  } catch (error) {
    console.error("Erro ao buscar pedidos:", error);
    return NextResponse.json({ error: "Erro ao buscar pedidos" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const data: Order = await request.json();

    if (!data.id || !data.customer?.name || !data.customer?.phone || !data.items || data.items.length === 0) {
      return NextResponse.json({ error: "Dados do pedido incompletos" }, { status: 400 });
    }

    const db = getDb();

    const stmt = db.prepare(`
      INSERT INTO orders (
        id, created_at, customer_name, customer_phone,
        delivery_address_json, items_json, subtotal, delivery_fee,
        discount, total, payment_method, status, device_id, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      data.id,
      data.createdAt || new Date().toISOString(),
      data.customer.name.trim(),
      data.customer.phone.trim(),
      JSON.stringify(data.deliveryAddress),
      JSON.stringify(data.items),
      Number(data.subtotal),
      Number(data.deliveryFee),
      Number(data.discount || 0),
      Number(data.total),
      data.paymentMethod || "PIX",
      data.status || "pendente",
      data.deviceId || null,
      data.notes?.trim() || null
    );

    const created = db.prepare("SELECT * FROM orders WHERE id = ?").get(data.id);
    return NextResponse.json(rowToOrder(created), { status: 201 });
  } catch (error) {
    console.error("Erro ao registrar pedido:", error);
    return NextResponse.json({ error: "Erro ao registrar pedido" }, { status: 500 });
  }
}

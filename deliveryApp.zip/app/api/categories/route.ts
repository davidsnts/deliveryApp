import { NextResponse } from "next/server";
import { getDb } from "@/app/lib/db";
import { Category } from "@/app/types";

export async function GET() {
  try {
    const db = getDb();
    const rows = db.prepare(`
      SELECT 
        c.id, 
        c.name, 
        c.icon, 
        (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) as count
      FROM categories c
    `).all();

    const categories: Category[] = rows.map((r: any) => ({
      id: r.id,
      name: r.name,
      icon: r.icon,
      count: Number(r.count),
    }));

    return NextResponse.json(categories);
  } catch (error) {
    console.error("Erro ao buscar categorias:", error);
    return NextResponse.json({ error: "Erro ao buscar categorias" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const data: Category[] = await request.json();
    if (!Array.isArray(data)) {
      return NextResponse.json({ error: "Dados inválidos" }, { status: 400 });
    }

    const db = getDb();
    const updateStmt = db.prepare("UPDATE categories SET name = ?, icon = ? WHERE id = ?");

    const updateTx = db.transaction(() => {
      for (const cat of data) {
        updateStmt.run(cat.name.trim(), cat.icon.trim(), cat.id);
      }
    });
    updateTx();

    const rows = db.prepare(`
      SELECT 
        c.id, 
        c.name, 
        c.icon, 
        (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) as count
      FROM categories c
    `).all();

    return NextResponse.json(rows);
  } catch (error) {
    console.error("Erro ao atualizar categorias:", error);
    return NextResponse.json({ error: "Erro ao atualizar categorias" }, { status: 500 });
  }
}

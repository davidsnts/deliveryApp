import { NextResponse } from "next/server";
import { getDb } from "@/app/lib/db";
import { Product } from "@/app/types";

// Helper to map DB row to Product interface
function rowToProduct(row: any): Product {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    price: Number(row.price),
    originalPrice: row.original_price ? Number(row.original_price) : undefined,
    image: row.image,
    category: row.category_id,
    restaurantId: row.restaurant_id,
    restaurantName: row.restaurant_name,
    rating: Number(row.rating),
    reviewsCount: Number(row.reviews_count),
    deliveryTime: row.delivery_time,
    isPopular: Boolean(row.is_popular),
    isOffer: Boolean(row.is_offer),
    freeDelivery: Boolean(row.free_delivery),
  };
}

export async function GET() {
  try {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM products ORDER BY rowid DESC").all();
    const products: Product[] = rows.map(rowToProduct);
    return NextResponse.json(products);
  } catch (error) {
    console.error("Erro ao listar produtos do SQLite:", error);
    return NextResponse.json({ error: "Erro ao buscar produtos" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const data: Partial<Product> = await request.json();

    if (!data.name || !data.price || !data.category) {
      return NextResponse.json({ error: "Nome, preço e categoria são obrigatórios" }, { status: 400 });
    }

    const db = getDb();
    const id = data.id || `item-${Date.now()}`;

    const stmt = db.prepare(`
      INSERT INTO products (
        id, name, description, price, original_price, image,
        category_id, restaurant_id, restaurant_name, rating,
        reviews_count, delivery_time, is_popular, is_offer, free_delivery
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      id,
      data.name.trim(),
      data.description?.trim() || "",
      Number(data.price),
      data.originalPrice ? Number(data.originalPrice) : null,
      data.image?.trim() || "",
      data.category,
      data.restaurantId || "rest-1",
      data.restaurantName || "Manga Com Pimenta",
      data.rating || 5.0,
      data.reviewsCount || 1,
      data.deliveryTime || "30-40 min",
      data.isPopular ? 1 : 0,
      data.isOffer ? 1 : 0,
      data.freeDelivery ? 1 : 0
    );

    const created = db.prepare("SELECT * FROM products WHERE id = ?").get(id);
    return NextResponse.json(rowToProduct(created), { status: 201 });
  } catch (error) {
    console.error("Erro ao cadastrar produto:", error);
    return NextResponse.json({ error: "Erro ao cadastrar produto" }, { status: 500 });
  }
}

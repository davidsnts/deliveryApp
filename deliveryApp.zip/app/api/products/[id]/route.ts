import { NextResponse } from "next/server";
import { getDb } from "@/app/lib/db";
import { Product } from "@/app/types";

function rowToProduct(row: any): Product {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    price: Number(row.price),
    originalPrice: row.original_price ? Number(row.original_price) : undefined,
    image: row.image,
    category: row.category_id,
    restaurantId: row.restaurant_id,
    restaurantName: row.restaurant_name,
    rating: Number(row.rating),
    reviewsCount: Number(row.reviews_count),
    deliveryTime: row.delivery_time,
    isPopular: Boolean(row.is_popular),
    isOffer: Boolean(row.is_offer),
    freeDelivery: Boolean(row.free_delivery),
  };
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data: Partial<Product> = await request.json();
    const db = getDb();

    const existing = db.prepare("SELECT * FROM products WHERE id = ?").get(id);
    if (!existing) {
      return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 });
    }

    const stmt = db.prepare(`
      UPDATE products SET
        name = ?,
        description = ?,
        price = ?,
        original_price = ?,
        image = ?,
        category_id = ?,
        delivery_time = ?,
        is_popular = ?,
        is_offer = ?,
        free_delivery = ?
      WHERE id = ?
    `);

    stmt.run(
      data.name?.trim() ?? (existing as any).name,
      data.description?.trim() ?? (existing as any).description,
      data.price !== undefined ? Number(data.price) : (existing as any).price,
      data.originalPrice !== undefined ? (data.originalPrice ? Number(data.originalPrice) : null) : (existing as any).original_price,
      data.image?.trim() ?? (existing as any).image,
      data.category ?? (existing as any).category_id,
      data.deliveryTime ?? (existing as any).delivery_time,
      data.isPopular !== undefined ? (data.isPopular ? 1 : 0) : (existing as any).is_popular,
      data.isOffer !== undefined ? (data.isOffer ? 1 : 0) : (existing as any).is_offer,
      data.freeDelivery !== undefined ? (data.freeDelivery ? 1 : 0) : (existing as any).free_delivery,
      id
    );

    const updated = db.prepare("SELECT * FROM products WHERE id = ?").get(id);
    return NextResponse.json(rowToProduct(updated));
  } catch (error) {
    console.error("Erro ao atualizar produto:", error);
    return NextResponse.json({ error: "Erro ao atualizar produto" }, { status: 500 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const db = getDb();

    const result = db.prepare("DELETE FROM products WHERE id = ?").run(id);
    if (result.changes === 0) {
      return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 });
    }

    return NextResponse.json({ success: true, deletedId: id });
  } catch (error) {
    console.error("Erro ao excluir produto:", error);
    return NextResponse.json({ error: "Erro ao excluir produto" }, { status: 500 });
  }
}
